package hangman;

public class LinkedListGameModel implements GameModel {
	
	
	//private LLCharacterNode start;
	//private LLCharacterNode end;
	
	LinkedListGameModel(String s) {
		//state   = STARTING_STATE;
		//listCount=0;
		//start = null;
		//end = null;
	}

	@Override
	public boolean isPriorGuess(char guess) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int numberOfGuesses() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isCorrectGuess(char guess) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean doMove(char guess) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean inWinningState() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean inLosingState() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getState() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String previousGuessString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getWord() {
		// TODO Auto-generated method stub
		return null;
	}

}
