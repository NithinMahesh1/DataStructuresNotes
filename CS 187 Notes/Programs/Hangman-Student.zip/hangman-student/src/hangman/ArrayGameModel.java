package hangman;

/**
 * The Array implementation of the GameModel interface.
 */
public class ArrayGameModel implements GameModel {
	/** The number of characters (lower/upper). */
	private static final int ALPHABET_COUNT = 26*2;
	
	/** hung state */
	private int state;
	
	/**
	 * Creates a new ArrayGameModel object.
	 * 
	 *  guessWord the word to guess
	 */
	int guessCount;
	char[] correctGuesses;
	char[] previousGuesses;
	char[] board;
	String wordGuess;
	
	
	public ArrayGameModel(String guessWord) {
		// TODO (1)
		guessCount = 0;
		board = new char[guessWord.length()]; 
		correctGuesses = new char[guessWord.length()];
		previousGuesses = new char[ALPHABET_COUNT];
		wordGuess = guessWord; 
		state   = STARTING_STATE;
	}
		
	public boolean isPriorGuess(char guess) {
		// TODO (2)
		for(int i=0; i<previousGuesses.length; i++) {
			
			if(previousGuesses[i] == guess) {
				return true;
			}
		}
		return false;
	}
	
	public int numberOfGuesses() {
		// TODO (3)
		return previousGuesses.length; 
	}
	
	public boolean isCorrectGuess(char guess) {
		// TODO (4)

		boolean correct = false;

		for (int i = 0; i < wordGuess.length(); i++) {
			if (wordGuess.charAt(i) == guess) {
				correct = true;
				for (int j = 0; j < previousGuesses.length; j++) {
					if(previousGuesses[i] == guess) {
						correct = false;
					}
				}
			}
		}
		return correct;
		
	}
	
	public boolean doMove(char guess) {
		// TODO (5)
	
		if(isPriorGuess(guess)){
			return false;
		}
		
		else if (isPriorGuess(guess) == false && isCorrectGuess(guess) == false) {
			state++;
			for(int i=0; i<previousGuesses.length; i++) {
				previousGuesses[i] = guess; 
			}
			return false;
		}
		
		else if(isCorrectGuess(guess) == true && isPriorGuess(guess) == false) {
			for(int i=0; i<wordGuess.length(); i++) {
				if(wordGuess.charAt(i) == guess) 
				{
					for(int n=0; n<previousGuesses.length; n++) {
						previousGuesses[i] = guess; 
					}
					for(int j=0; j<correctGuesses.length; j++) {
						correctGuesses[i] = guess;
					}
					board[i] = guess;
					return true;
				}
			}
		}
		
		return false;

	}

	public boolean inWinningState() {
		// TODO (6)
		int count = 0;
		for(int i=0; i<wordGuess.length(); i++) {
			if(wordGuess.charAt(i) == correctGuesses[i]) {
				count++;
			}
		}
		if(count == wordGuess.length()-1) {
			return true; 
		}
		return false;
	}

	public boolean inLosingState() {
		// TODO(7)
		if(state == 10) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public String toString() {
		// TODO (8)
		String s = "";
		for(int i=0; i<board.length-1; i++){
			s = s + board[i]+ " _";
		}
		
		return s.trim();
	}

	public String previousGuessString() {
		String s = "[";
		 //create a s+=veryfirstindex in array [", "
		//create a for loop whereever array is not equal to zero 
		// add s+= Arrayname[for loop variable] + ", ";
		//another for loop print everything in the string minus the last two characters in the string 
		//closing bracket before return s
		// TODO (9)
		//s+=board.indexOf(0);
		
		for(int i=0; i<previousGuesses.length; i++) {
				s += previousGuesses[i]+ " ";
		}
		//for(int j=0; )
		//return "]";
		return s;
	}
	
	public int getState() {
		return state;
	}

	public String getWord() {

		// TODO (10)
		return wordGuess;
		//return null;
	}
  
}
